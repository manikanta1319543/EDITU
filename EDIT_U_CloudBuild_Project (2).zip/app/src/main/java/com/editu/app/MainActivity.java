package com.editu.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_REEL = 101;
    private static final int PICK_PHOTOS = 102;
    private static final int PICK_MUSIC = 103;
    private TextView reelStatus, photoStatus, musicStatus, planStatus;
    private Uri reelUri, musicUri;
    private ArrayList<Uri> photoUris = new ArrayList<>();

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,8,8));
        getWindow().setNavigationBarColor(Color.rgb(8,8,8));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(8,8,8));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = new TextView(this);
        logo.setText("EU");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(22);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(roundBg(0xFF202020, dp(16)));
        brand.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));
        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(13), 0, 0, 0);
        TextView name = new TextView(this); name.setText("EDIT U"); name.setTextColor(Color.WHITE);
        name.setTextSize(23); name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView tagline = new TextView(this); tagline.setText("AUTOMATIC REEL STUDIO");
        tagline.setTextColor(0xFF9D9D9D); tagline.setTextSize(10);
        brandText.addView(name); brandText.addView(tagline); brand.addView(brandText);
        root.addView(brand);
        addSpace(root, 22);

        TextView hero = new TextView(this);
        hero.setText("Your style.\\nYour photos.\\nOne finished Reel.");
        hero.setTextColor(Color.WHITE); hero.setTextSize(28);
        hero.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hero.setPadding(dp(18), dp(20), dp(18), dp(20));
        hero.setBackground(roundBg(0xFF171717, dp(20)));
        root.addView(hero, matchWrap());
        TextView intro = label("Add a reference video, your photos, and optional music. EDIT U will prepare an edit plan.", 14, 0xFFB6B6B6);
        intro.setPadding(dp(2), dp(13), dp(2), dp(10)); root.addView(intro);

        reelStatus = status("No reference Reel selected");
        photoStatus = status("No photos selected");
        musicStatus = status("No music selected (optional)");
        addPicker(root, "1  Choose reference Reel", "Pick a video", PICK_REEL, reelStatus);
        addPicker(root, "2  Choose your photos", "Select photos", PICK_PHOTOS, photoStatus);
        addPicker(root, "3  Add music (optional)", "Choose audio", PICK_MUSIC, musicStatus);

        Button generate = button("CREATE MY EDIT PLAN");
        generate.setBackground(roundBg(Color.WHITE, dp(14)));
        generate.setTextColor(Color.BLACK);
        generate.setOnClickListener(v -> makePlan());
        LinearLayout.LayoutParams gp = matchWrap(); gp.topMargin = dp(16); root.addView(generate, gp);

        planStatus = label("Your edit plan will appear here.", 13, 0xFFB7B7B7);
        planStatus.setPadding(dp(15), dp(15), dp(15), dp(15));
        planStatus.setBackground(roundBg(0xFF141414, dp(14)));
        LinearLayout.LayoutParams pp = matchWrap(); pp.topMargin = dp(12); root.addView(planStatus, pp);

        TextView note = label("STARTER VERSION • This screen selects your media and prepares a basic plan. Automatic beat-sync, transitions, and final video export are not implemented in this starter yet.", 11, 0xFF777777);
        note.setPadding(dp(3), dp(20), dp(3), 0); root.addView(note);
    }

    private void addPicker(LinearLayout root, String title, String btnText, int request, TextView status) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(roundBg(0xFF151515, dp(16)));
        TextView heading = label(title, 15, Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(heading);
        status.setPadding(0, dp(6), 0, dp(10)); card.addView(status);
        Button b = button(btnText);
        b.setOnClickListener(v -> pick(request));
        card.addView(b, matchWrap());
        LinearLayout.LayoutParams cp = matchWrap(); cp.topMargin = dp(10); root.addView(card, cp);
    }

    private void pick(int request) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        if (request == PICK_REEL) intent.setType("video/*");
        else if (request == PICK_PHOTOS) intent.setType("image/*");
        else intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        if (request == PICK_PHOTOS) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, request);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_REEL) {
            reelUri = data.getData();
            reelStatus.setText(reelUri == null ? "No video selected" : "Reference Reel selected ✓");
        } else if (requestCode == PICK_MUSIC) {
            musicUri = data.getData();
            musicStatus.setText(musicUri == null ? "No audio selected" : "Music/audio selected ✓");
        } else if (requestCode == PICK_PHOTOS) {
            photoUris.clear();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) photoUris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) photoUris.add(data.getData());
            photoStatus.setText(photoUris.size() + (photoUris.size() == 1 ? " photo selected ✓" : " photos selected ✓"));
        }
    }

    private void makePlan() {
        if (reelUri == null || photoUris.isEmpty()) {
            Toast.makeText(this, "Choose a reference Reel and at least one photo.", Toast.LENGTH_LONG).show();
            return;
        }
        String msg = "EDIT PLAN READY\\n\\nReference video: selected\\nYour photos: " + photoUris.size() +
                "\\nMusic: " + (musicUri == null ? "not selected" : "selected") +
                "\\n\\nNext render stage: analyse shot timing, map your photos to each beat, apply transitions and effects, then export MP4.";
        planStatus.setText(msg);
    }

    private TextView status(String s) { return label(s, 12, 0xFFAAAAAA); }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(Color.WHITE); b.setBackground(roundBg(0xFF292929, dp(12))); return b;
    }
    private android.graphics.drawable.GradientDrawable roundBg(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private void addSpace(LinearLayout root, int height) {
        View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }
}
