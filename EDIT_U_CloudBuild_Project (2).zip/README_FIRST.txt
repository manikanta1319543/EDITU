EDIT U — Android cloud-build project

This is a build-ready starter Android project, not a precompiled APK. The current app lets users select a reference video, multiple photos, and optional audio, then displays an edit-plan summary. It does NOT yet analyse the reference video or render an automatically edited MP4.

HOW TO BUILD AN APK WITHOUT INSTALLING ANDROID STUDIO LOCALLY
1. Create/sign in to a GitHub account.
2. Create a new repository (for example: edit-u-android).
3. Upload the contents of this ZIP to the repository root (not the outer folder).
4. Open the repository's Actions tab.
5. Choose "Build EDIT U APK" and click "Run workflow" (or push to main).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, find Artifacts, and download EDIT-U-debug-apk.zip.
8. Extract it to get app-debug.apk. Transfer the APK to your Android phone and install it. Android may ask you to allow installing apps from that source.

SAFETY / REALITY CHECK
- The debug APK is for testing, not a Play Store release.
- The automatic AI matching, beat sync, effects rendering, and final MP4 export are future development work.
- No company/network permission is needed for ordinary editing features.
- Never upload private photos or videos to an untrusted website/repository. This project code does not include your selected media files.
